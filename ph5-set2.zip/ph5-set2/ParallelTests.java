package com.testannotations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelTests {

	WebDriver driver;

	@Test(groups = "Chrome")
	public void LaunchChrome() {
		System.setProperty("webdriver.chrome.driver", "C:\\tools\\seleniumtools\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.browserstack.com/");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(groups = "Chrome", dependsOnMethods = "LaunchChrome")
	public void Trychrome() {
		driver.get("https://www.browserstack.com/users/sign_up");
		System.out.println(Thread.currentThread().getId());
		driver.findElement(By.id("user_full_name")).sendKeys("sai");
		driver.findElement(By.id("user_email_login")).sendKeys("sai@gmail.com");
		driver.findElement(By.id("user_password")).sendKeys("123");
		System.out.println(
				"this is the test related to chrome browserstack login" + " " + Thread.currentThread().getId());
	}

	@Test(groups = "Firefox")
	public void LaunchFirefox() {
		System.setProperty("webdriver.gecko.driver",
				"C:\\tools\\seleniumtools\\geckodriver-v0.31.0-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.browserstack.com/");
		try {
			Thread.sleep(4000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(groups = "Firefox", dependsOnMethods = "LaunchFirefox")
	public void TryFirefox() {
		System.out.println(Thread.currentThread().getId());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.browserstack.com/users/sign_up");
		driver.manage().window().maximize();
		driver.findElement(By.id("user_full_name")).sendKeys("hsello");
		driver.findElement(By.id("user_email_login")).sendKeys("helo@gmail.com");
		driver.findElement(By.id("user_password")).sendKeys("<password>");
	}
}
