package com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsSet2Prj6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
