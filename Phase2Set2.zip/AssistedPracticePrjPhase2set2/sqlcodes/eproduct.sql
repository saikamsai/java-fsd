use mydb;
CREATE TABLE eproduct (ID bigint primary key auto_increment, name varchar(100), price decimal(10,2), date_added timestamp default now());
INSERT INTO eproduct values (101, 'HP Laptop', 12000, now()) ;
INSERT INTO eproduct values (102, 'Acer Laptop', 14000,now()) ;
INSERT INTO eproduct values (103, 'Lenovo Laptop', 13000,now()) ;
 select* from eproduct;
