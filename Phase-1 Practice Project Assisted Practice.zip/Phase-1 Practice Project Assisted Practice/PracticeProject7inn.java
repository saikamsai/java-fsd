public class PracticeProject7inn {

	public static void main(String[] args) {
		PracticeProject7Abs i = new PracticeProject7Abs() {

	         public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      i.display();
	   }
	}