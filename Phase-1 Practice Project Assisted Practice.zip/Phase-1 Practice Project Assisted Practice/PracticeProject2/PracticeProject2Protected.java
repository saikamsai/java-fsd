package PracticeProject2;
import PracticeProject2met.*;

public class PracticeProject2Protected extends PracticeProject2pro {

	public static void main(String[] args) {
		PracticeProject2Protected obj = new PracticeProject2Protected ();   
	       obj.display();  
	}

}

