package PracticeProject2;

import PracticeProject2met.*;

public class PracticeProject2public {

	public static void main(String[] args) {
		
		PracticeProject2Pub obj = new PracticeProject2Pub(); 
        obj.display();  
		
	}
}