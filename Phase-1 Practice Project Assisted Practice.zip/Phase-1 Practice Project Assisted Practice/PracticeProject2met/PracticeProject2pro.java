package PracticeProject2met;

public class PracticeProject2pro {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

}
