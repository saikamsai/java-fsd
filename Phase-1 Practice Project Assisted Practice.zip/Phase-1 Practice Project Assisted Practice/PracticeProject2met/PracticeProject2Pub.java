package PracticeProject2met;

public class PracticeProject2Pub {

	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}

