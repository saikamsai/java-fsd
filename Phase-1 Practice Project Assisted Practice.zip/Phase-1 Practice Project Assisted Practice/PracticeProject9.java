
public class PracticeProject9 {
	public static void main(String[] args) {

		//single-dimensional array
		int a[]= {1,3,5,7,9,11};
		for(int i=0;i<6;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b = {
		            {2, 4, 6}, 
		            {3, 6} };
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      }


}
