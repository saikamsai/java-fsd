//anonymous inner class
abstract class PracticeProject7Abs {
	   public abstract void display();
	}


	
