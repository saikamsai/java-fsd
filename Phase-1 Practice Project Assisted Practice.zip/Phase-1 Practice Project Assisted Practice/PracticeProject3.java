//method demo
public class PracticeProject3 {

public double multipynumbers(double a,double b) {
	double c=a*b;
	return c;
}

public static void main(String[] args) {

	PracticeProject3 d=new PracticeProject3();
	double res= d.multipynumbers(10.8,5);
	System.out.println("Multipilcation is :"+res);
	}

}



