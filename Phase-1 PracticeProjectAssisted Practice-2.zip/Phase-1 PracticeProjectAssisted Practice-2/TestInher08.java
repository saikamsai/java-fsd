public class TestInher08  
{ 
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(5, 80, 24); 
        System.out.println(mb.toString());
    } 
}
